import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pageable',
  templateUrl: './pageable.component.html',
  styleUrls: ['./pageable.component.css']
})
export class PageableComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
