export class People {
    id!: number;
    name!: string;
    imageUrl!: string;
}
